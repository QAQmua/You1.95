// 📄 替换文件：AppCore (核心系统与桌面)/LockScreenView.swift
// MARK: - 4. LockScreenView (锁屏主视图 · 设备自适应版)
import SwiftUI
import UIKit

struct LockScreenView: View {
    @Binding var isUnlocked: Bool
    
    @ObservedObject var wallpaperManager = WallpaperManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var lang = LanguageManager.shared
    
    var contentColor: Color {
        wallpaperManager.isLockLight ? .black : .white
    }
    
    private let timeFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter
    }()
    
    private func localizedDateString(for date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: lang.currentLanguage.localeIdentifier)
        switch lang.currentLanguage {
        case .simplifiedChinese, .traditionalChinese:
            formatter.dateFormat = "EEEE, M月d日"
        case .english:
            formatter.dateFormat = "EEEE, MMMM d"
        case .japanese:
            formatter.dateFormat = "M月d日 EEEE"
        case .korean:
            formatter.dateFormat = "M월 d일 EEEE"
        }
        return formatter.string(from: date)
    }
    
    var body: some View {
        VStack {
            Image(systemName: "lock.fill")
                .font(.system(size: 22.0 * uiScale))
                .foregroundColor(contentColor)
                .padding(.top, 60.0 * uiScale)
            
            TimelineView(.periodic(from: .now, by: 1.0)) { context in
                VStack(spacing: 0) {
                    Text(timeFormatter.string(from: context.date))
                        .font(.system(size: 80.0 * uiScale, weight: .ultraLight, design: .rounded))
                        .foregroundColor(contentColor)
                    
                    Text(localizedDateString(for: context.date))
                        .font(.system(size: 20.0 * uiScale))
                        .fontWeight(appearance.systemFontWeight)
                        .foregroundColor(wallpaperManager.isLockLight ? Color.black.opacity(0.6) : .gray)
                }
            }
            
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .fontWeight(appearance.systemFontWeight)
        .background(NativeImage(data: wallpaperManager.lockScreenData).ignoresSafeArea())
        .overlay(alignment: .bottom) {
            Capsule()
                .fill(contentColor)
                .frame(width: 130.0 * uiScale, height: 5.0 * uiScale)
                .padding(.bottom, 10.0 * uiScale)
        }
        .ignoresSafeArea(.all, edges: .bottom)
        .gesture(
            DragGesture()
                .onEnded { value in
                    if value.translation.height < (-50.0 * uiScale) {
                        withAnimation(.easeInOut(duration: 0.4)) {
                            isUnlocked = true
                        }
                    }
                }
        )
    }
}
