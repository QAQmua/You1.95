import SwiftUI

struct BookItem: Identifiable {
    let id = UUID()
    let title: String
    let author: String
    let category: String
    let coverColor: Color
}

struct QimaoNovelView: View {
    @Binding var show: Bool
    @ObservedObject var appearance = SystemAppearance.shared 
    @ObservedObject var lang = LanguageManager.shared
    
    let books: [BookItem] = [
        BookItem(title: "极客修真录", author: "幼刀", category: "玄幻仙侠", coverColor: .indigo),
        BookItem(title: "时空边缘的便利店", author: "猫猫队长", category: "治愈科幻", coverColor: .orange),
        BookItem(title: "逆袭从桌面代码开始", author: "无名氏", category: "都市爽文", coverColor: .blue),
        BookItem(title: "深空观测手册", author: "星海", category: "硬核科幻", coverColor: .teal)
    ]
    
    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 20) {
                    // 今日畅读横幅
                    HStack {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("七猫免费小说 · 每日精选".tr)
                                .font(.caption.weight(.bold))
                                .foregroundColor(.orange)
                            Text("百部热门小说 永久免费读".tr)
                                .font(.system(size: 18, weight: .bold))
                            Text("海量高分好书，字字声情并茂".tr)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        Spacer()
                        Image(systemName: "books.vertical.fill")
                            .font(.system(size: 40))
                            .foregroundColor(.orange.opacity(0.8))
                    }
                    .padding(18)
                    .background(Color.orange.opacity(0.12))
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .padding(.horizontal, 16)
                    .padding(.top, 12)
                    
                    // 我的书架
                    VStack(alignment: .leading, spacing: 14) {
                        Text("近期在读书架".tr)
                            .font(.system(size: 17, weight: appearance.systemFontWeight))
                            .padding(.horizontal, 16)
                        
                        LazyVGrid(columns: [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)], spacing: 14) {
                            ForEach(books) { book in
                                VStack(alignment: .leading, spacing: 8) {
                                    ZStack(alignment: .bottomLeading) {
                                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                                            .fill(book.coverColor.gradient)
                                            .frame(height: 140)
                                        
                                        VStack(alignment: .leading, spacing: 3) {
                                            Text(book.category.tr)
                                                .font(.system(size: 9, weight: .bold))
                                                .padding(.horizontal, 6)
                                                .padding(.vertical, 2)
                                                .background(.ultraThinMaterial)
                                                .clipShape(Capsule())
                                            Text(book.title.tr)
                                                .font(.system(size: 15, weight: .bold))
                                                .foregroundColor(.white)
                                                .lineLimit(2)
                                        }
                                        .padding(10)
                                    }
                                    
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(book.title.tr)
                                            .font(.system(size: 14, weight: appearance.systemFontWeight))
                                            .foregroundColor(.primary)
                                            .lineLimit(1)
                                        Text(book.author.tr)
                                            .font(.caption2)
                                            .foregroundColor(.secondary)
                                    }
                                }
                            }
                        }
                        .padding(.horizontal, 16)
                    }
                }
                .padding(.bottom, 24)
            }
            .navigationTitle(lang.tr("app_qimao"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button(action: {
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { show = false }
                    }) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 16, weight: appearance.systemFontWeight))
                            .foregroundColor(.primary)
                    }
                }
            }
            .background(Color(UIColor.systemBackground))
        }
        .preferredColorScheme(appearance.colorScheme)
        .simultaneousGesture(
            DragGesture(minimumDistance: 15).onEnded { value in
                if value.translation.width > 50 && abs(value.translation.width) > abs(value.translation.height) {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { show = false }
                }
            }
        )
    }
}
