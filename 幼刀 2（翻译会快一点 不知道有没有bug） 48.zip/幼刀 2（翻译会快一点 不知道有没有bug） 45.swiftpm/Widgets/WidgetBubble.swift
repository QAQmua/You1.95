// MARK: - 5. WidgetBubble (2×2 对话框组件：自适应高度严丝合缝版)
import SwiftUI
import PhotosUI

class ChatBubbleWidgetManager: ObservableObject {
    static let shared = ChatBubbleWidgetManager()
    
    private let photoIdKey = "App_Widget_2x2_Bubble_ImageID"
    private let firstKey = "App_Widget_2x2_Bubble_FirstText"
    private let secondKey = "App_Widget_2x2_Bubble_SecondText"
    private let addedKey = "App_Widget_2x2_Bubble_IsAdded"
    private let pageKey = "App_Widget_2x2_Bubble_PagePosition"
    private let rowKey = "App_Widget_2x2_Bubble_RowPosition"
    private let colKey = "App_Widget_2x2_Bubble_ColPosition"
    private let transparentKey = "App_Widget_2x2_Bubble_IsTransparent"
    
    private let bubbleColorKey = "App_Widget_2x2_Bubble_BgColor"
    private let textColorKey = "App_Widget_2x2_Bubble_TextColor"
    private let dateColorKey = "App_Widget_2x2_Bubble_DateColor"
    private let bubbleWeightKey = "App_Widget_2x2_Bubble_TextWeight"
    
    @Published var widgetImageData: Data? {
        didSet {
            let oldId = UserDefaults.standard.string(forKey: photoIdKey)
            LocalImageStore.shared.replace(oldId: oldId, with: widgetImageData) { newId in
                UserDefaults.standard.set(newId, forKey: self.photoIdKey)
            }
        }
    }
    
    @Published var firstBubbleText: String {
        didSet {
            UserDefaults.standard.set(firstBubbleText, forKey: firstKey)
            AutoTranslationManager.shared.prewarm(text: firstBubbleText)
        }
    }
    
    @Published var secondBubbleText: String {
        didSet {
            UserDefaults.standard.set(secondBubbleText, forKey: secondKey)
            AutoTranslationManager.shared.prewarm(text: secondBubbleText)
        }
    }
    
    @Published var isTransparentBackground: Bool { didSet { UserDefaults.standard.set(isTransparentBackground, forKey: transparentKey) } }
    @Published var isAddedToDesktop: Bool { didSet { UserDefaults.standard.set(isAddedToDesktop, forKey: addedKey) } }
    @Published var widgetPage: Int { didSet { UserDefaults.standard.set(widgetPage, forKey: pageKey) } }
    @Published var widgetRow: Int { didSet { UserDefaults.standard.set(widgetRow, forKey: rowKey) } }
    @Published var widgetCol: Int { didSet { UserDefaults.standard.set(widgetCol, forKey: colKey) } }
    
    @Published var bubbleColorHex: String { didSet { UserDefaults.standard.set(bubbleColorHex, forKey: bubbleColorKey) } }
    @Published var textColorHex: String { didSet { UserDefaults.standard.set(textColorHex, forKey: textColorKey) } }
    @Published var dateColorHex: String { didSet { UserDefaults.standard.set(dateColorHex, forKey: dateColorKey) } }
    
    @Published var bubbleTextWeightName: String {
        didSet { UserDefaults.standard.set(bubbleTextWeightName, forKey: bubbleWeightKey) }
    }
    
    var bubbleColor: Color { Color(hex: bubbleColorHex) }
    var bubbleTextColor: Color { Color(hex: textColorHex) }
    var dateTextColor: Color { Color(hex: dateColorHex) }
    var bubbleTextWeight: Font.Weight { Font.Weight.from(name: bubbleTextWeightName) }
    
    init() {
        if let savedId = UserDefaults.standard.string(forKey: photoIdKey) {
            self.widgetImageData = LocalImageStore.shared.load(id: savedId)
        }
        self.firstBubbleText = UserDefaults.standard.string(forKey: firstKey) ?? "幼"
        self.secondBubbleText = UserDefaults.standard.string(forKey: secondKey) ?? "其实很可爱的哦..."
        self.isTransparentBackground = UserDefaults.standard.bool(forKey: transparentKey)
        self.isAddedToDesktop = UserDefaults.standard.bool(forKey: addedKey)
        self.widgetPage = UserDefaults.standard.integer(forKey: pageKey)
        let rawRow = UserDefaults.standard.object(forKey: rowKey) != nil ? UserDefaults.standard.integer(forKey: rowKey) : 2
        self.widgetRow = min(max(0, rawRow), 4)
        
        let rawCol = UserDefaults.standard.integer(forKey: colKey)
        self.widgetCol = (rawCol > 0) ? 2 : 0
        
        self.bubbleColorHex = UserDefaults.standard.string(forKey: bubbleColorKey) ?? "#E5E5EA"
        self.textColorHex = UserDefaults.standard.string(forKey: textColorKey) ?? "#000000"
        self.dateColorHex = UserDefaults.standard.string(forKey: dateColorKey) ?? "#8E8E93"
        self.bubbleTextWeightName = UserDefaults.standard.string(forKey: bubbleWeightKey) ?? "medium"
        
        AutoTranslationManager.shared.prewarm(text: firstBubbleText)
        AutoTranslationManager.shared.prewarm(text: secondBubbleText)
    }
}

struct ChatBubbleWidget2x2View: View {
    var imageData: Data?
    var firstBubbleText: String = "幼"
    var secondBubbleText: String = "其实很可爱的哦..."
    var isTransparent: Bool = false
    var bubbleColor: Color = Color(UIColor.systemGray5)
    var bubbleTextColor: Color = .primary
    var dateTextColor: Color = Color.secondary.opacity(0.75)
    var bubbleTextWeight: Font.Weight = .medium
    var isEditing: Bool = false
    var showDashedBorder: Bool = false
    var onDelete: (() -> Void)? = nil
    
    @ObservedObject var lang = LanguageManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    
    @State private var currentDate: Date = Date()
    private static let sharedFormatter = DateFormatter()
    
    private var formattedDate: String {
        Self.sharedFormatter.locale = Locale(identifier: lang.currentLanguage.localeIdentifier)
        switch lang.currentLanguage {
        case .simplifiedChinese, .traditionalChinese: Self.sharedFormatter.dateFormat = "M月d日 EEEE"
        case .english: Self.sharedFormatter.dateFormat = "EEEE, MMM d"
        case .japanese: Self.sharedFormatter.dateFormat = "M月d日(EEEE)"
        case .korean: Self.sharedFormatter.dateFormat = "M월 d일 EEEE"
        }
        return Self.sharedFormatter.string(from: currentDate)
    }
    
    private func effectiveWeight(_ customWeight: Font.Weight) -> Font.Weight {
        appearance.preferWidgetFontPriority ? customWeight : appearance.systemFontWeight
    }
    
    var body: some View {
        ZStack(alignment: .topLeading) {
            VStack(alignment: .leading, spacing: 5) {
                HStack {
                    Spacer()
                    Text(formattedDate)
                        .font(.system(size: 8.5))
                        .fontWeight(appearance.systemFontWeight)
                        .foregroundColor(dateTextColor)
                        .lineLimit(1)
                    Spacer()
                }
                .padding(.top, -3)
                
                HStack {
                    Text(translator.translate(firstBubbleText))
                        .font(.system(size: 10))
                        .fontWeight(effectiveWeight(bubbleTextWeight))
                        .foregroundColor(bubbleTextColor)
                        .lineLimit(1)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 3)
                        .background(bubbleColor)
                        .clipShape(Capsule())
                    Spacer(minLength: 0)
                }
                .padding(.leading, 10)
                
                HStack(alignment: .bottom, spacing: 6) {
                    Group {
                        if let data = imageData, let uiImage = ImageBitmapCache.shared.image(from: data) {
                            Image(uiImage: uiImage).resizable().scaledToFill()
                        } else {
                            ZStack {
                                Color(UIColor.systemGray6)
                                Image(systemName: "photo")
                                    .font(.system(size: 24))
                                    .foregroundColor(.secondary.opacity(0.5))
                            }
                        }
                    }
                    .frame(width: 114, height: 64)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .stroke(Color.primary.opacity(0.06), lineWidth: 0.8)
                    )
                    
                    Image(systemName: "arrowshape.turn.up.right.fill")
                        .font(.system(size: 8))
                        .foregroundColor(.white)
                        .frame(width: 18, height: 18)
                        .background(Color.primary.opacity(0.2))
                        .clipShape(Circle())
                        .padding(.bottom, 2)
                    Spacer(minLength: 0)
                }
                .padding(.leading, 10)
                
                HStack {
                    Text(translator.translate(secondBubbleText))
                        .font(.system(size: 9.5))
                        .fontWeight(effectiveWeight(bubbleTextWeight))
                        .foregroundColor(bubbleTextColor)
                        .lineLimit(1)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 3.5)
                        .background(bubbleColor)
                        .clipShape(Capsule())
                    Spacer(minLength: 0)
                }
                .padding(.leading, 10)
                .padding(.bottom, 6)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity) // 🌟 撑满外部
            .background(isTransparent ? Color.clear : Color(UIColor.secondarySystemGroupedBackground))
            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .stroke(
                        isTransparent ? (showDashedBorder ? Color.secondary.opacity(0.4) : Color.clear) : Color.white.opacity(0.2),
                        style: StrokeStyle(lineWidth: 1, dash: (isTransparent && showDashedBorder) ? [5, 4] : [])
                    )
            )
            .contentShape(Rectangle())
            
            if isEditing, let onDelete = onDelete {
                Button(action: onDelete) { WidgetDeleteBadge() }
                    .padding(8)
                    .transition(.scale.combined(with: .opacity))
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity) // 🌟 删除了写死的 frame(height: 160)
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.significantTimeChangeNotification).receive(on: DispatchQueue.main)) { _ in
            currentDate = Date()
        }
    }
}

struct EditBubbleWidgetSheet: View {
    @Binding var isPresented: Bool
    @ObservedObject var chatBubbleManager = ChatBubbleWidgetManager.shared
    
    @State private var selectedBubblePhotoItem: PhotosPickerItem? = nil
    
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    
    private let bubbleColorPresets = ["#E5E5EA", "#FFFFFF", "#1C1C1E", "#D0E1FD", "#FDE2E4", "#E2ECE9", "#FFF1C5", "#E8DFF5"]
    private let textColorPresets = ["#000000", "#FFFFFF", "#3C3C43", "#007AFF", "#FF2D55", "#5856D6"]
    private let dateColorPresets = ["#8E8E93", "#000000", "#FFFFFF", "#007AFF", "#FF9500"]
    
    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(spacing: 18) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 22, style: .continuous)
                            .fill(Color(UIColor.secondarySystemGroupedBackground))
                            .frame(height: 185)
                        
                        ChatBubbleWidget2x2View(
                            imageData: chatBubbleManager.widgetImageData,
                            firstBubbleText: chatBubbleManager.firstBubbleText,
                            secondBubbleText: chatBubbleManager.secondBubbleText,
                            isTransparent: chatBubbleManager.isTransparentBackground,
                            bubbleColor: chatBubbleManager.bubbleColor,
                            bubbleTextColor: chatBubbleManager.bubbleTextColor,
                            dateTextColor: chatBubbleManager.dateTextColor,
                            bubbleTextWeight: chatBubbleManager.bubbleTextWeight,
                            showDashedBorder: true
                        )
                        .frame(width: 160, height: 160)
                        .shadow(color: Color.black.opacity(0.08), radius: 12, y: 4)
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 10)
                    
                    VStack(spacing: 0) {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("第一条气泡文案".tr)
                                .font(.caption2)
                                .foregroundColor(.secondary)
                            
                            TextField("输入文案".tr, text: $chatBubbleManager.firstBubbleText)
                                .font(.subheadline)
                                .padding(10)
                                .background(Color(UIColor.tertiarySystemFill))
                                .cornerRadius(10)
                                .onChange(of: chatBubbleManager.firstBubbleText) { _, newText in
                                    translator.prewarm(text: newText)
                                }
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                        
                        Divider().padding(.leading, 16)
                        
                        VStack(alignment: .leading, spacing: 6) {
                            Text("第二条气泡文案".tr)
                                .font(.caption2)
                                .foregroundColor(.secondary)
                            
                            TextField("输入文案".tr, text: $chatBubbleManager.secondBubbleText)
                                .font(.subheadline)
                                .padding(10)
                                .background(Color(UIColor.tertiarySystemFill))
                                .cornerRadius(10)
                                .onChange(of: chatBubbleManager.secondBubbleText) { _, newText in
                                    translator.prewarm(text: newText)
                                }
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                    }
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(18)
                    .padding(.horizontal, 16)
                    
                    VStack(spacing: 0) {
                        PhotosPicker(selection: $selectedBubblePhotoItem, matching: .images, photoLibrary: .shared()) {
                            HStack {
                                Label("更换照片".tr, systemImage: "photo.badge.plus")
                                    .font(.system(size: 15, weight: appearance.systemFontWeight))
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .font(.caption.weight(.semibold))
                                    .foregroundColor(.secondary)
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 14)
                        }
                        .foregroundColor(.primary)
                        
                        Divider().padding(.leading, 16)
                        
                        Toggle(isOn: $chatBubbleManager.isTransparentBackground) {
                            Label("背景透明模式".tr, systemImage: "circle.lefthalf.filled")
                                .font(.system(size: 15, weight: appearance.systemFontWeight))
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                    }
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(18)
                    .padding(.horizontal, 16)
                    
                    VStack(alignment: .leading, spacing: 14) {
                        Text("色彩与字体样式".tr)
                            .font(.system(size: 13, weight: appearance.systemFontWeight))
                            .foregroundColor(.secondary)
                            .padding(.horizontal, 16)
                            .padding(.top, 14)
                        
                        WidgetFontWeightPicker(title: "气泡文字粗细".tr, selectedWeightName: $chatBubbleManager.bubbleTextWeightName)
                            .padding(.horizontal, 16)
                        
                        Divider().padding(.leading, 16)
                        
                        WidgetColorPaletteRow(
                            title: "气泡背景".tr,
                            selectedHex: chatBubbleManager.bubbleColorHex,
                            presets: bubbleColorPresets,
                            currentColor: chatBubbleManager.bubbleColor,
                            onSelectHex: { chatBubbleManager.bubbleColorHex = $0 },
                            onPickColor: { chatBubbleManager.bubbleColorHex = $0.toHex() }
                        )
                        .padding(.horizontal, 16)
                        
                        Divider().padding(.leading, 16)
                        
                        WidgetColorPaletteRow(
                            title: "气泡文字".tr,
                            selectedHex: chatBubbleManager.textColorHex,
                            presets: textColorPresets,
                            currentColor: chatBubbleManager.bubbleTextColor,
                            onSelectHex: { chatBubbleManager.textColorHex = $0 },
                            onPickColor: { chatBubbleManager.textColorHex = $0.toHex() }
                        )
                        .padding(.horizontal, 16)
                        
                        Divider().padding(.leading, 16)
                        
                        WidgetColorPaletteRow(
                            title: "顶部日期".tr,
                            selectedHex: chatBubbleManager.dateColorHex,
                            presets: dateColorPresets,
                            currentColor: chatBubbleManager.dateTextColor,
                            onSelectHex: { chatBubbleManager.dateColorHex = $0 },
                            onPickColor: { chatBubbleManager.dateColorHex = $0.toHex() }
                        )
                        .padding(.horizontal, 16)
                        .padding(.bottom, 14)
                    }
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(18)
                    .padding(.horizontal, 16)
                }
                .padding(.bottom, 32)
            }
            .background(Color(UIColor.systemGroupedBackground))
            .navigationTitle("定制对话框".tr)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成".tr) {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        isPresented = false
                    }
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                }
            }
        }
        .presentationDetents([.medium, .large])
        .task(id: selectedBubblePhotoItem) {
            if let data = try? await selectedBubblePhotoItem?.loadTransferable(type: Data.self) {
                withAnimation(.easeInOut(duration: 0.25)) { chatBubbleManager.widgetImageData = data }
            }
        }
    }
}

extension WidgetRegistry {
    func registerBubbleWidget() {
        registerWidget(
            id: "bubble",
            title: "widget_bubble_title",
            subtitle: "sub_bubble",
            badge: "2×2",
            manager: ChatBubbleWidgetManager.shared,
            desktopView: {
                ChatBubbleWidget2x2View(
                    imageData: ChatBubbleWidgetManager.shared.widgetImageData,
                    firstBubbleText: ChatBubbleWidgetManager.shared.firstBubbleText,
                    secondBubbleText: ChatBubbleWidgetManager.shared.secondBubbleText,
                    isTransparent: ChatBubbleWidgetManager.shared.isTransparentBackground,
                    bubbleColor: ChatBubbleWidgetManager.shared.bubbleColor,
                    bubbleTextColor: ChatBubbleWidgetManager.shared.bubbleTextColor,
                    dateTextColor: ChatBubbleWidgetManager.shared.dateTextColor,
                    bubbleTextWeight: ChatBubbleWidgetManager.shared.bubbleTextWeight
                )
            },
            previewView: {
                ChatBubbleWidget2x2View(
                    imageData: ChatBubbleWidgetManager.shared.widgetImageData,
                    firstBubbleText: ChatBubbleWidgetManager.shared.firstBubbleText,
                    secondBubbleText: ChatBubbleWidgetManager.shared.secondBubbleText,
                    isTransparent: ChatBubbleWidgetManager.shared.isTransparentBackground,
                    bubbleColor: ChatBubbleWidgetManager.shared.bubbleColor,
                    bubbleTextColor: ChatBubbleWidgetManager.shared.bubbleTextColor,
                    dateTextColor: ChatBubbleWidgetManager.shared.dateTextColor,
                    bubbleTextWeight: ChatBubbleWidgetManager.shared.bubbleTextWeight
                ).frame(width: 160, height: 160)
            },
            editSheetView: { show in
                EditBubbleWidgetSheet(isPresented: show)
            }
        )
    }
}
