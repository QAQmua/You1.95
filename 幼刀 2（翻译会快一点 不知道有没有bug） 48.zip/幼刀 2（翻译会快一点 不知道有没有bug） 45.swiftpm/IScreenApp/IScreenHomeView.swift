// 📄 新文件：IScreenHomeView.swift
import SwiftUI

struct IScreenHomeView: View {
    @ObservedObject var viewModel: IScreenViewModel
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var registry = WidgetRegistry.shared
    @ObservedObject var lang = LanguageManager.shared
    
    @FocusState var isSearchFocused: Bool
    
    var body: some View {
        VStack(spacing: 0) {
            searchBarHeaderView
            
            if viewModel.isSearching {
                searchHistoryAndResultView
            } else {
                homeRecommendScrollView
            }
        }
    }
    
    // MARK: - 搜索栏
    private var searchBarHeaderView: some View {
        HStack(spacing: 0) {
            HStack(spacing: 8) {
                Image(systemName: "magnifyingglass").font(.system(size: 15, weight: .medium)).foregroundColor(.secondary)
                TextField("搜索小组件、图标主题...".tr, text: $viewModel.searchText)
                    .font(.system(size: 14, weight: appearance.systemFontWeight))
                    .foregroundColor(.primary)
                    .focused($isSearchFocused)
                
                if !viewModel.searchText.isEmpty {
                    Button(action: { viewModel.searchText = "" }) {
                        Image(systemName: "xmark.circle.fill").font(.system(size: 14)).foregroundColor(.secondary)
                    }
                }
            }
            .frame(maxWidth: .infinity).frame(height: 38).padding(.horizontal, 12)
            .background(Color(UIColor.secondarySystemFill)).clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
            
            if viewModel.isSearching {
                Button(action: {
                    withAnimation(.easeInOut(duration: 0.22)) {
                        isSearchFocused = false
                        viewModel.isSearching = false
                        viewModel.searchText = ""
                    }
                }) {
                    Text("取消".tr).font(.system(size: 16, weight: appearance.systemFontWeight)).foregroundColor(.gray).padding(.leading, 12).fixedSize()
                }
                .transition(.move(edge: .trailing).combined(with: .opacity))
            }
        }
        .padding(.horizontal, 16).padding(.top, 12).padding(.bottom, 8)
        .animation(.easeInOut(duration: 0.22), value: viewModel.isSearching)
        .onChange(of: isSearchFocused) { _, focused in
            if focused && !viewModel.isSearching { withAnimation(.easeInOut(duration: 0.22)) { viewModel.isSearching = true } }
        }
    }
    
    // MARK: - 搜索结果
    private var searchHistoryAndResultView: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 20) {
                if viewModel.searchText.trimmingCharacters(in: .whitespaces).isEmpty {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("搜索历史".tr).font(.system(size: 14, weight: appearance.systemFontWeight)).foregroundColor(.secondary)
                            Spacer()
                            if !viewModel.searchHistory.isEmpty {
                                Button(action: { withAnimation { viewModel.searchHistory.removeAll() } }) { Image(systemName: "trash").font(.caption).foregroundColor(.secondary) }
                            }
                        }
                        if viewModel.searchHistory.isEmpty {
                            Text("暂无搜索历史".tr).font(.caption).foregroundColor(.secondary.opacity(0.6)).padding(.top, 4)
                        } else {
                            FlowLayout(spacing: 8) {
                                ForEach(viewModel.searchHistory, id: \.self) { item in
                                    Button(action: { viewModel.searchText = item }) {
                                        Text(item.tr).font(.system(size: 12, weight: appearance.systemFontWeight)).foregroundColor(.primary).padding(.horizontal, 12).padding(.vertical, 6).background(Color(UIColor.secondarySystemFill)).clipShape(Capsule())
                                    }
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 16).padding(.top, 8)
                } else {
                    let results = viewModel.allPresets.filter { $0.title.localizedCaseInsensitiveContains(viewModel.searchText) || $0.category.localizedCaseInsensitiveContains(viewModel.searchText) }
                    VStack(alignment: .leading, spacing: 12) {
                        Text("\("搜索结果".tr) (\(results.count))").font(.caption).foregroundColor(.secondary).padding(.horizontal, 16)
                        if results.isEmpty {
                            VStack(spacing: 12) {
                                Image(systemName: "magnifyingglass").font(.system(size: 32)).foregroundColor(.secondary.opacity(0.4)).padding(.top, 40)
                                Text("\("未找到与".tr)“\(viewModel.searchText)”\("相关的内容".tr)").font(.subheadline).foregroundColor(.secondary)
                            }.frame(maxWidth: .infinity)
                        } else {
                            LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), spacing: 14)], spacing: 14) {
                                ForEach(results, id: \.title) { item in
                                    presetWidgetCard(title: item.title, category: item.category, icon: item.icon, color: item.color)
                                }
                            }.padding(.horizontal, 16)
                        }
                    }
                }
            }
            .padding(.top, 8).padding(.bottom, 20)
        }
    }
    
    // MARK: - 推荐组件列表
    private var homeRecommendScrollView: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 14) {
                VStack(alignment: .leading, spacing: 10) {
                    Text("热门推荐".tr).font(.system(size: 17, weight: appearance.systemFontWeight)).padding(.horizontal, 16).padding(.top, 8)
                    HStack(spacing: 8) {
                        ForEach(viewModel.categoryFilters, id: \.self) { filter in
                            Button(action: {
                                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                withAnimation(.spring(response: 0.28, dampingFraction: 0.85)) { viewModel.selectedCategoryFilter = filter }
                            }) {
                                Text(filter == "全部" ? "全部".tr : filter)
                                    .font(.system(size: 12, weight: viewModel.selectedCategoryFilter == filter ? .semibold : appearance.systemFontWeight))
                                    .padding(.horizontal, 14).padding(.vertical, 6)
                                    .background(viewModel.selectedCategoryFilter == filter ? Color.blue : Color(UIColor.secondarySystemFill))
                                    .foregroundColor(viewModel.selectedCategoryFilter == filter ? .white : .secondary).clipShape(Capsule())
                            }
                        }
                        Spacer()
                    }.padding(.horizontal, 16)
                }
                
                ForEach(registry.registeredWidgets) { widget in
                    if isWidgetMatchingFilter(widget: widget, filter: viewModel.selectedCategoryFilter) {
                        VStack(alignment: .leading, spacing: 14) {
                            HStack {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(lang.tr(widget.titleKey)).font(.system(size: 17, weight: appearance.systemFontWeight))
                                    Text(lang.tr(widget.subtitleKey)).font(.caption).foregroundColor(.secondary)
                                }
                                Spacer()
                                if widget.id != "photo" {
                                    Button(action: {
                                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                        viewModel.activeEditWidgetID = widget.id
                                    }) {
                                        HStack(spacing: 4) {
                                            Image(systemName: "slider.horizontal.3").font(.system(size: 11, weight: .semibold))
                                            Text("定制".tr).font(.system(size: 12, weight: appearance.systemFontWeight))
                                        }
                                        .padding(.horizontal, 10).padding(.vertical, 4).background(Color.blue.opacity(0.12)).foregroundColor(.blue).clipShape(Capsule())
                                    }
                                }
                                Text(widget.manager.isAddedToDesktop ? "已在桌面".tr : "未添加".tr).font(.caption2.weight(.medium)).padding(.horizontal, 8).padding(.vertical, 3).background(widget.manager.isAddedToDesktop ? Color.blue.opacity(0.1) : Color(UIColor.tertiarySystemFill)).foregroundColor(widget.manager.isAddedToDesktop ? .blue : .secondary).clipShape(Capsule())
                            }
                            
                            Button(action: {
                                if widget.id != "photo" {
                                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                    viewModel.activeEditWidgetID = widget.id
                                }
                            }) {
                                HStack {
                                    if widget.sizeCols < 4 { Spacer() }
                                    widget.previewView()
                                    if widget.sizeCols < 4 { Spacer() }
                                }
                            }
                            .buttonStyle(.plain)
                        }
                        .padding(16).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(22)
                        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Color.primary.opacity(0.06), lineWidth: 1))
                        .padding(.horizontal, 16)
                        .transition(.asymmetric(insertion: .opacity.combined(with: .scale(scale: 0.98)), removal: .opacity))
                    }
                }
            }
            .animation(.spring(response: 0.3, dampingFraction: 0.86), value: viewModel.selectedCategoryFilter)
            .padding(.bottom, 20)
        }
    }
    
    private func presetWidgetCard(title: String, category: String, icon: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack { Image(systemName: icon).font(.title2).foregroundColor(color); Spacer(); Text(category.tr).font(.system(size: 10, weight: .bold)).padding(.horizontal, 6).padding(.vertical, 2).background(color.opacity(0.15)).foregroundColor(color).clipShape(Capsule()) }
            Text(title.tr).font(.system(size: 14, weight: appearance.systemFontWeight))
            Text("支持自定义规格".tr).font(.system(size: 10)).foregroundColor(.secondary)
        }.padding(14).frame(height: 105).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(16)
    }
    
    private func isWidgetMatchingFilter(widget: WidgetDefinition, filter: String) -> Bool {
        if filter == "全部" { return true }
        let target = filter.lowercased().replacingOccurrences(of: "×", with: "x")
        let badge = widget.sizeBadgeKey.lowercased().replacingOccurrences(of: "×", with: "x")
        if target == badge { return true }
        
        switch target {
        case "2x2": return widget.sizeCols == 2 && widget.sizeRows == 2
        case "4x2": return (widget.sizeCols == 4 && widget.sizeRows == 2) || (widget.sizeCols == 2 && widget.sizeRows == 4)
        case "4x4": return widget.sizeCols == 4 && widget.sizeRows == 4
        default: return false
        }
    }
}
